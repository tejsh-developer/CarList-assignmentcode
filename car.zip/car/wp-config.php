<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'car' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'TC<s7PAE/TXhd2Tc~z#pm[^6bA:L]qu*|)m[H<5|T8F|X.A#  7(n;$tzg>}W]Ye' );
define( 'SECURE_AUTH_KEY',  ')5G=4u34Y5L|u&(xa!9=#c$bzLY9z2fzAi[.+bOU<x-T2>8(d9QpoidoybBP :WL' );
define( 'LOGGED_IN_KEY',    'T]>f1h+#Y(]1:4Fv%d{SG&<yn>v>K|VvwD44B>cr79Kc}dh(d<*1S<ez-Fqx/CcP' );
define( 'NONCE_KEY',        '{Z`T%{2#74@t+e6CAPoP6@U!|}9/` w/5HlVgSugGrF{gI;(d6,1`=~7:IYLKTg&' );
define( 'AUTH_SALT',        'BL3S/,j#abfig!,ZKq;a|:,dtKn07;n.v#D^A{a3@OF(/b^A|Z[/8A)`Ng/f=rs#' );
define( 'SECURE_AUTH_SALT', 'V1O|~0kSeyMM2/:$WvOeu$v&3obizK8Z=UrRZqfvx&r$/uNLGzkNWjNFhf2-{//~' );
define( 'LOGGED_IN_SALT',   'KIkWJ<tM^&LtT]$hPS, Y#3yT;SpQ]t?R2vRYp//HZ-3ljLrH{r2 I33K1$An=!i' );
define( 'NONCE_SALT',       '2zh(EHi~?oE9L AhzX+,H#+O[#%EogDQ|Q4J u^=8o)$0<yi{to+vDjQ%}}XI4o?' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
